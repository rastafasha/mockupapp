<div class="menu-footer">
                    <ul>

                        <li class="active">
                            <a href="home.html">
                                <i class="fa fa-home"></i>
                            </a>
                        </li>
                        <li>
                            <a href="favorites.html">
                                <i class="fa fa-heart"></i></li>
                        </a>
                        <li>
                            <a href="search.html">
                                <i class="fa fa-search"></i></li>
                        </a>
                        <li>
                            <a href="wallet.html">
                                <i class="fa fa-bookmark"></i></li>
                        </a>
                        <li>
                            <a href="user.html">
                                <i class="fa fa-user"></i></li>
                        </a>
                    </ul>
                </div>