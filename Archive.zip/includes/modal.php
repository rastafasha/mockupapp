
<!-- Modal -->
<div class="modal  animated fadeInUp" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-body">
                <a href="#" data-bs-dismiss="modal" class="">

                    <div class="barratop"></div>
                </a>
                <h3>Login with</h3>

                <a href="login.html">


                    <div class=" group">
                        <i class="fa fa-google" aria-hidden="true"></i>
                        <div class="div1">
                            <h2>Google Verfify</h2>
                            <p>emailaddress@gmail.com</p>
                        </div>
                    </div>

                </a>
                <a href="login.html">
                    <div class=" group">
                        <i class="fa fa-facebook" aria-hidden="true"></i>
                        <div class="div1">
                            <h2>Facebook Verfify</h2>
                            <p>emailaddress@gmail.com</p>
                        </div>
                    </div>
                </a>


                <div class="col-auto mb-2">
                    <input class="form-control form-control-md" type="text" placeholder="Username" aria-label=".form-control-lg example">
                </div>
                <div class="col-auto mb-2">
                    <input class="form-control form-control-md" type="text" placeholder="Password" aria-label=".form-control-lg example">
                </div>

            </div>
            <div class="modal-footer footer-modal">
                <button type="button" class="btn btn-simple-gray" data-bs-dismiss="modal">Cancel</button>
                <a href="login.html">
                    <button type="button" class="btn btn-outline-red" data-bs-dismiss="modal">Login</button>
                </a>
            </div>
        </div>
    </div>
</div>